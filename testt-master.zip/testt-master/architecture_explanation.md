# 🏗️ Project Architecture — Bampokha Mining Waste Detection System

> A satellite-based AI system that detects marble mining waste dumps at the **Bampokha Marble City** site in Buner, KP, Pakistan — and visualizes them on an interactive 3D globe.

---

## 1. High-Level System Overview

```mermaid
graph LR
    subgraph Frontend ["Frontend (React + Vite)"]
        A["index.html"] --> B["main.jsx"]
        B --> C["App.jsx"]
        C --> D["Globe.jsx (CesiumJS)"]
        C --> E["MapboxGlobe.jsx"]
        C --> F["SearchBar.jsx"]
        C --> G["SidebarLeft.jsx"]
    end

    subgraph Backend ["Backend (FastAPI + Python)"]
        H["main.py (FastAPI)"]
        I["best.pt (YOLOv8 Model)"]
        J["OpenCV Pipeline"]
        K["mines.geojson"]
    end

    subgraph Data ["Data Pipeline"]
        L["_annotations.coco.json"]
        M["coco_to_geojson.py"]
        N["sample.jpg"]
        O["masks/ (41 PNGs)"]
    end

    C -- "fetch /mines.geojson" --> K2["public/mines.geojson"]
    C -- "POST /detect" --> H
    H --> I
    H --> J
    L --> M
    M --> K
```

The project is a **full-stack geospatial AI application** with two major parts:

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Frontend** | React 19 + Vite 8 | Interactive 3D globe with mine polygon overlay |
| **Backend** | FastAPI + YOLOv8 + OpenCV | AI-powered satellite image analysis |
| **Data Pipeline** | Python scripts | Convert COCO annotations → GeoJSON polygons |

---

## 2. Frontend Architecture (Step by Step)

### Step 2.1 — Entry Point

```
index.html → src/main.jsx → src/App.jsx
```

- [index.html](file:///e:/testt/index.html) — Standard HTML shell with a `<div id="root">` mount point
- [main.jsx](file:///e:/testt/src/main.jsx) — React entry; renders `<App />` into the root div
- [vite.config.js](file:///e:/testt/vite.config.js) — Vite config with two plugins:
  - `@vitejs/plugin-react` — React JSX/HMR support
  - `vite-plugin-cesium` — Handles CesiumJS static asset bundling (workers, WASM, etc.)

### Step 2.2 — App.jsx (The Brain of the Frontend)

[App.jsx](file:///e:/testt/src/App.jsx) is the **central orchestrator**. It manages:

| Responsibility | How |
|---|---|
| **Map engine switching** | `mapEngine` state toggles between `'cesium'` and `'mapbox'` |
| **Globe instance tracking** | `activeMap` holds the current CesiumJS Viewer or Mapbox Map object |
| **Mine data loading** | Fetches `public/mines.geojson` on startup and stores in `minesData` |
| **Mine polygon rendering** | `renderStaticMines()` draws GeoJSON polygons on whichever engine is active |
| **Search & fly-to** | `handleSearch()` flies the camera to a location using Cesium/Mapbox APIs |
| **Analysis simulation** | `triggerVisionDetection()` simulates AI detection and generates waste stats |
| **Live detection jitter** | A `setInterval` that oscillates the detection percentage ±0.05 every 2 seconds |

#### Data Flow inside App.jsx:

```mermaid
sequenceDiagram
    participant User
    participant App
    participant Globe
    participant GeoJSON as public/mines.geojson

    Note over App: On Mount
    App->>GeoJSON: fetch('/mines.geojson')
    GeoJSON-->>App: 16 KML mine polygons
    App->>App: setMinesData(data)

    Note over App: When map + data ready
    App->>Globe: renderStaticMines(geojsonData)
    Globe-->>User: Blue polygons on globe

    Note over User: Clicks "Analyze Bampokha"
    User->>App: handleSearch({lat: 34.5141, lon: 72.3})
    App->>Globe: camera.flyTo(Bampokha coords)
    Globe-->>App: flight complete callback
    App->>App: triggerVisionDetection()
    App->>App: generateWasteStats()
    App-->>User: Updates detection % in UI
```

### Step 2.3 — Globe.jsx (CesiumJS 3D Engine)

[Globe.jsx](file:///e:/testt/src/components/Globe.jsx) initializes a full **CesiumJS Viewer** with:

| Feature | Detail |
|---|---|
| **Imagery** | `IonWorldImageryStyle.AERIAL_WITH_LABELS` — satellite tiles with place names |
| **Terrain** | `createWorldTerrainAsync()` — 3D terrain elevation from Cesium Ion |
| **Camera Controls** | Zoom, rotate, tilt, look — all enabled with min/max zoom limits |
| **Visual Quality** | `resolutionScale: 2.0`, FXAA anti-aliasing, HDR, sky atmosphere |
| **Authentication** | Uses a Cesium Ion token passed as prop |

When ready, it calls `onReady(viewer)` to pass the Cesium Viewer instance back to `App.jsx`.

### Step 2.4 — MapboxGlobe.jsx (Alternative Engine)

[MapboxGlobe.jsx](file:///e:/testt/src/components/MapboxGlobe.jsx) provides a **Mapbox GL JS** alternative:

- Uses `projection: 'globe'` for a 3D globe view
- Satellite + street labels style (`satellite-streets-v12`)
- Atmospheric fog with stars for the "space" look
- Requires a Mapbox access token via `VITE_MAPBOX_ACCESS_TOKEN` environment variable

### Step 2.5 — SearchBar.jsx (Location Search)

[SearchBar.jsx](file:///e:/testt/src/components/SearchBar.jsx) provides geocoding:

1. User types a location name
2. Calls **Nominatim OpenStreetMap API** (`nominatim.openstreetmap.org/search`)
3. Shows up to 5 results in a dropdown
4. On selection, calls `onSearch({ lat, lon, rawResult })` → App flies the camera there

### Step 2.6 — SidebarLeft.jsx (Control Panel)

[SidebarLeft.jsx](file:///e:/testt/src/components/SidebarLeft.jsx) contains:

- **Map Engine Switcher** — Buttons to toggle between CesiumJS and Mapbox GL
- **Exemplars Section** — Placeholder for indexed features (currently empty)
- **Sensitivity Slider** — Detection threshold control (UI only, defaults to 50%)
- **Brand Footer** — "Earth 3D" with gradient text

### Step 2.7 — Styling (App.css)

[App.css](file:///e:/testt/src/App.css) implements a premium dark UI:

- **Glassmorphism** — `backdrop-filter: blur(20px)` with semi-transparent backgrounds
- **Design Tokens** — CSS variables for accent color (`#00C8FF`), fonts (Inter, Space Grotesk)
- **Animations** — Slide-in cards, pulse effects, spin loaders
- **Layout** — Full-viewport app with fixed sidebars and absolute-positioned overlays

---

## 3. Backend Architecture (Step by Step)

### Step 3.1 — FastAPI Server

[main.py](file:///e:/testt/backend/main.py) is a FastAPI server with a single endpoint:

```
POST /detect
```

**Dependencies** ([requirements.txt](file:///e:/testt/backend/requirements.txt)):

| Package | Purpose |
|---|---|
| `fastapi` | Web framework |
| `uvicorn` | ASGI server |
| `ultralytics` | YOLOv8 model inference |
| `opencv-python-headless` | Image processing (no GUI) |
| `numpy` | Array operations |
| `python-multipart` | File upload parsing |

### Step 3.2 — Model Loading

On startup, the server loads:

1. **`best.pt`** (~40 MB) — A custom-trained YOLOv8 segmentation model that detects mining waste dumps in satellite imagery
2. **`masks/`** (41 PNG files) — Pre-generated mask images for fast rendering
3. **`mines.geojson`** — Pre-computed static mine polygons (loaded as fallback features)

### Step 3.3 — The `/detect` Endpoint (AI Pipeline)

The detection pipeline has **4 stages**:

```mermaid
flowchart TD
    A["📸 Receive Image\n(uploaded file or sample.jpg)"] --> B["🔧 Stage 0: Pre-Process\nCLAHE Contrast Enhancement"]
    B --> C["🤖 Stage 1: AI Signal\nYOLOv8 Segmentation\nconf=0.1, imgsz=1024"]
    C --> D["👁️ Stage 2: Vision Fallback\nMarble-Specific HSV Filter"]
    D --> E["📊 Stage 3: Stats\nCoverage % Calculation"]
    E --> F["📦 Stage 4: Response\nGeoJSON FeatureCollection"]

    style A fill:#1a1a2e,color:#fff
    style C fill:#003399,color:#fff
    style D fill:#16213e,color:#fff
```

#### Stage 0 — Pre-Processing (CLAHE)
```python
# Convert to LAB color space → Apply CLAHE to lightness channel
lab = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2LAB)
clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
```
This normalizes contrast in satellite images so both shadowed and bright areas are detectable.

#### Stage 1 — YOLO Segmentation (AI Signal)
- Runs YOLOv8 with `conf=0.1` (low threshold to catch faint deposits)
- Resolution: `imgsz=1024` for detail
- Extracts **instance segmentation masks** (polygon outlines, not just bounding boxes)
- Converts pixel-coordinate masks → geo-coordinates using `pixel_to_latlon()`

#### Stage 2 — HSV Vision Fallback
When YOLO misses deposits, a classical computer vision filter catches **white/grey marble**:
```python
# Marble is ultra-bright white: any hue, low saturation, very high value
lower_marble = np.array([0,   0, 210])
upper_marble = np.array([180, 35, 255])
```
Then applies morphological open/close to clean noise and extracts contours.

#### Stage 3 — Stats Calculation
- Counts waste pixels vs total pixels → `coverage_pct`
- If AI signal is weak (< 0.1% or < 2 detections), falls back to **realistic simulated stats** (30–40% range) based on the pre-annotated polygons

#### Stage 4 — GeoJSON Response
Returns a `FeatureCollection` containing:
1. **Site boundary** — A bounding box around the Bampokha study area
2. **Static mine polygons** — Pre-annotated from COCO dataset
3. **AI-detected polygons** — From YOLO + HSV pipeline

### Step 3.4 — Coordinate Conversion

The critical `pixel_to_latlon()` function maps image pixels to real-world coordinates:

```python
def pixel_to_latlon(x, y, img_w, img_h, bbox):
    # bbox = [min_lon, min_lat, max_lon, max_lat]
    lon = min_lon + (x / img_w) * (max_lon - min_lon)
    lat = max_lat - (y / img_h) * (max_lat - min_lat)  # y=0 is top (max_lat)
```

The default bounding box is anchored to: **34.524450°N, 72.300950°E** (Bampokha Marble City center).

---

## 4. Data Pipeline (Step by Step)

### Step 4.1 — Source Data

| File | Description |
|---|---|
| `_annotations.coco.json` (~94 KB) | Hand-annotated mine polygons in COCO format from Roboflow |
| `sample.jpg` (~17 MB) | High-resolution satellite image of the Bampokha mining site |
| `masks/` (41 PNGs) | Binary mask images of individual mine detections |

### Step 4.2 — COCO → GeoJSON Conversion

[coco_to_geojson.py](file:///e:/testt/backend/coco_to_geojson.py) converts pixel annotations to geo-referenced polygons:

```mermaid
flowchart LR
    A["COCO JSON\n(pixel coords)"] --> B["Per-Image BBox\nCalculation"]
    B --> C["pixel_to_latlon()\nConversion"]
    C --> D["mines.geojson\n(lat/lon polygons)"]

    style A fill:#1a1a2e,color:#fff
    style D fill:#003399,color:#fff
```

**Key logic:**
1. Reads COCO annotations with pixel-coordinate segmentation masks
2. Determines a geographic bounding box per image based on resolution class:
   - 8192×4320 → 0.075° (~7 km) — overview shots
   - 1920×1080 → 0.042° (~4 km) — medium zoom
   - 1485×892 → 0.035° (~3.3 km) — medium-close
   - 1116×632 → 0.028° (~2.6 km) — close-up
3. Converts each pixel polygon to lat/lon coordinates
4. Outputs `mines.geojson` with all polygon features

### Step 4.3 — GeoJSON Distribution

The generated `mines.geojson` exists in **two locations**:
- `backend/mines.geojson` (~26 KB, 16 polygons) — Used by the FastAPI server
- `public/mines.geojson` (~157 KB, more detailed) — Served directly to the frontend

---

## 5. Complete Request Lifecycle

Here's what happens end-to-end when a user clicks **"Analyze Bampokha"**:

```mermaid
sequenceDiagram
    actor User
    participant UI as React UI
    participant App as App.jsx
    participant Cesium as CesiumJS Globe
    participant API as FastAPI Backend
    participant YOLO as YOLOv8 Model
    participant CV as OpenCV

    User->>UI: Click "Analyze Bampokha"
    UI->>App: handleSearch({lat: 34.5141, lon: 72.3})
    App->>App: setIsRotating(false)
    App->>Cesium: camera.flyTo(72.3°E, 34.51°N, alt: 15000m)
    
    Note over Cesium: 3.5s animated flight

    Cesium-->>App: flight complete callback
    App->>App: setIsAnalyzing(true)
    App->>App: triggerVisionDetection()
    
    Note over App: 1.2s simulated delay

    App->>App: generateWasteStats()
    App->>App: setIsAnalyzing(false)
    App-->>UI: Update detection % & stats

    Note over UI: Static mine polygons are<br/>already rendered from<br/>public/mines.geojson<br/>(loaded on startup)
```

> [!NOTE]
> In the current implementation, the frontend does **not** call the `/detect` backend endpoint during the "Analyze Bampokha" flow. It simulates the analysis client-side via `triggerVisionDetection()`. The backend `/detect` endpoint is designed for **real-time satellite image uploads** where actual YOLO inference is needed.

---

## 6. File-by-File Summary

### Frontend Files

| File | Lines | Purpose |
|------|-------|---------|
| [index.html](file:///e:/testt/index.html) | 14 | HTML entry point |
| [main.jsx](file:///e:/testt/src/main.jsx) | ~5 | React DOM render |
| [App.jsx](file:///e:/testt/src/App.jsx) | 276 | Core orchestrator — state, search, rendering |
| [App.css](file:///e:/testt/src/App.css) | 380 | All styling — glassmorphism, animations |
| [Globe.jsx](file:///e:/testt/src/components/Globe.jsx) | 126 | CesiumJS 3D globe initialization |
| [MapboxGlobe.jsx](file:///e:/testt/src/components/MapboxGlobe.jsx) | 76 | Mapbox GL 3D globe alternative |
| [SearchBar.jsx](file:///e:/testt/src/components/SearchBar.jsx) | 98 | Location search via Nominatim API |
| [SidebarLeft.jsx](file:///e:/testt/src/components/SidebarLeft.jsx) | 66 | Engine switcher + controls |
| [SidebarRight.jsx](file:///e:/testt/src/components/SidebarRight.jsx) | 47 | Explore/Discoveries list (not currently rendered) |

### Backend Files

| File | Size | Purpose |
|------|------|---------|
| [main.py](file:///e:/testt/backend/main.py) | 283 lines | FastAPI server with `/detect` endpoint |
| [coco_to_geojson.py](file:///e:/testt/backend/coco_to_geojson.py) | 103 lines | Offline conversion: COCO → GeoJSON |
| [best.pt](file:///e:/testt/backend/best.pt) | ~40 MB | Trained YOLOv8 segmentation model |
| [sample.jpg](file:///e:/testt/backend/sample.jpg) | ~17 MB | Default satellite image for inference |
| [_annotations.coco.json](file:///e:/testt/backend/_annotations.coco.json) | ~94 KB | Source COCO annotations |
| [mines.geojson](file:///e:/testt/backend/mines.geojson) | ~26 KB | Generated mine polygons |
| `masks/` | 41 files | Pre-extracted mask images |

---

## 7. Technology Stack Summary

```mermaid
graph TB
    subgraph Frontend
        React["React 19"]
        Vite["Vite 8"]
        CesiumJS["CesiumJS 1.140"]
        Mapbox["Mapbox GL 3.21"]
        Lucide["Lucide React Icons"]
    end

    subgraph Backend
        FastAPI["FastAPI"]
        YOLO["YOLOv8 (Ultralytics)"]
        OpenCV["OpenCV"]
        NumPy["NumPy"]
        Uvicorn["Uvicorn"]
    end

    subgraph External
        Nominatim["OpenStreetMap Nominatim"]
        CesiumIon["Cesium Ion (tiles + terrain)"]
        MapboxTiles["Mapbox Satellite Tiles"]
    end

    Frontend --> External
    Backend --> YOLO
    Backend --> OpenCV
```

---

## 8. How to Run

### Frontend
```bash
cd e:\testt
npm install
npm run dev          # → http://localhost:5173
```

### Backend
```bash
cd e:\testt\backend
pip install -r requirements.txt
uvicorn main:app --reload   # → http://localhost:8000
```

### Data Pipeline (one-time)
```bash
cd e:\testt\backend
python coco_to_geojson.py   # Generates mines.geojson from COCO annotations
```
