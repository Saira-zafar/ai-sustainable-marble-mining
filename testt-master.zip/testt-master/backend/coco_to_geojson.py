import json
import os

def pixel_to_latlon(x, y, img_w, img_h, bbox):
    """Convert pixel coordinates to lat/lon. bbox = [min_lon, min_lat, max_lon, max_lat]"""
    min_lon, min_lat, max_lon, max_lat = bbox
    lon = min_lon + (x / img_w) * (max_lon - min_lon)
    lat = max_lat - (y / img_h) * (max_lat - min_lat)
    return [round(lon, 7), round(lat, 7)]

# ─── PATHS ───────────────────────────────────────────────────────────────────
ANNOTATIONS_PATH = "_annotations.coco.json"
OUTPUT_PATH       = "mines.geojson"

# ─── CONFIRMED GPS ANCHOR ────────────────────────────────────────────────────
# Source: Environmental Study of Bampokha Marble City, Buner KP
# Center of mining activity: 34.524450°N, 72.300950°E
CX = 72.3010   # confirmed center longitude
CY = 34.5220   # mine cluster center latitude (slightly south of Marble City)

# Geographic coverage per image resolution class (degrees longitude width)
# Derived from GEP zoom level analysis anchored to confirmed coordinates
SIZE_WIDTHS = {
    (8192, 4320): 0.075,   # ~7 km — full area overview shots
    (1920, 1080): 0.042,   # ~4 km — medium zoom
    (1485,  892): 0.035,   # ~3.3 km — medium-close zoom
    (1116,  632): 0.028,   # ~2.6 km — close-up mine shots
}

def make_bbox(center_lon, center_lat, width_deg, img_w, img_h):
    """Build [min_lon, min_lat, max_lon, max_lat] centered at point."""
    aspect = img_w / img_h
    # 111.0 km/° lat vs 111.3*cos(lat) km/° lon ≈ correction factor ~0.989 at 34.5°
    height_deg = width_deg / aspect * (111.0 / (111.3 * 0.826))
    return [
        round(center_lon - width_deg / 2, 6),
        round(center_lat - height_deg / 2, 6),
        round(center_lon + width_deg / 2, 6),
        round(center_lat + height_deg / 2, 6),
    ]

# ─── LOAD DATA ───────────────────────────────────────────────────────────────
if not os.path.exists(ANNOTATIONS_PATH):
    print(f"ERROR: {ANNOTATIONS_PATH} not found"); exit(1)

with open(ANNOTATIONS_PATH) as f:
    coco = json.load(f)

image_map = {img["id"]: img for img in coco["images"]}

# Build per-image bboxes from size class
image_bboxes = {}
for img in coco["images"]:
    w, h = img["width"], img["height"]
    width_deg = SIZE_WIDTHS.get((w, h), 0.030)
    image_bboxes[img["file_name"]] = make_bbox(CX, CY, width_deg, w, h)

# ─── CONVERT ANNOTATIONS TO GEOJSON POLYGONS ─────────────────────────────────
features = []

for ann in coco["annotations"]:
    image  = image_map[ann["image_id"]]
    fname  = image["file_name"]
    img_w, img_h = image["width"], image["height"]
    bbox   = image_bboxes[fname]

    for seg in ann["segmentation"]:
        if not seg or len(seg) < 6:
            continue

        # Increased resolution (max 150 points) to match live high-fidelity look
        pts = [(seg[i], seg[i+1]) for i in range(0, len(seg)-1, 2)]
        step = max(1, len(pts) // 150)
        sampled = pts[::step]

        coords = [pixel_to_latlon(px, py, img_w, img_h, bbox) for px, py in sampled]

        # Close the ring
        if coords[0] != coords[-1]:
            coords.append(coords[0])

        if len(coords) < 4:
            continue

        features.append({
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [coords]},
            "properties": {
                "class":         "marble_mine",
                "orig_image":    image["extra"]["name"],
                "type":          "static-mine",
                "confidence":    1.0,
                "annotation_id": ann["id"]
            }
        })

# ─── SAVE ────────────────────────────────────────────────────────────────────
geojson = {"type": "FeatureCollection", "features": features}
with open(OUTPUT_PATH, "w") as f:
    json.dump(geojson, f, indent=2)

print(f"[SUCCESS] {OUTPUT_PATH} written - {len(features)} polygon features from {len(coco['images'])} images")
