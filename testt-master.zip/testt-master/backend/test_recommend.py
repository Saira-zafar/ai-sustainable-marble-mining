import urllib.request
import json
import urllib.error

url = 'http://127.0.0.1:8000/recommend'
payload = {
    'coverage_pct': 32.02,
    'detection_count': 16,
    'waste_ha': 420.5
}

req = urllib.request.Request(url, method='POST')
req.add_header('Content-Type', 'application/json')
data = json.dumps(payload).encode('utf-8')

try:
    print("Sending request to /recommend...")
    r = urllib.request.urlopen(req, data=data)
    print("SUCCESS")
    print(r.read().decode('utf-8'))
except urllib.error.HTTPError as e:
    print("HTTP ERROR:", e.code)
    print(e.read().decode('utf-8'))
except Exception as e:
    print("ERROR:", e)
