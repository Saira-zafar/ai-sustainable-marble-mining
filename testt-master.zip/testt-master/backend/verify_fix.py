import requests
import json

def test_bampokha_detection():
    url = "http://127.0.0.1:8000/detect"
    # Bampokha bounding box
    params = {"bbox": "72.275,34.505,72.325,34.535"}
    
    try:
        # We don't send an image, so it will use sample.jpg (fallback)
        response = requests.post(url, params=params)
        response.raise_for_status()
        data = response.json()
        
        print(f"Total features found: {len(data['features'])}")
        
        knowledge_base_count = 0
        waste_zones_count = 0
        
        for feature in data['features']:
            props = feature['properties']
            if "Knowledge-Base" in props.get('class', ''):
                knowledge_base_count += 1
            if props.get('type') == 'waste-zone':
                waste_zones_count += 1
        
        print(f"Knowledge-Base detections: {knowledge_base_count}")
        print(f"Total waste-zone typed features: {waste_zones_count}")
        
        if knowledge_base_count > 0:
            print("SUCCESS: Knowledge-base detections are present!")
        else:
            print("FAILURE: No knowledge-base detections found for Bampokha bbox.")
            
    except Exception as e:
        print(f"ERROR: {e}")

if __name__ == "__main__":
    test_bampokha_detection()
