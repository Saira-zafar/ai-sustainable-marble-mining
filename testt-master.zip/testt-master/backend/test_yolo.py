from ultralytics import YOLO
import cv2

model = YOLO("best.pt")
img = cv2.imread("sample.jpg")

# Test 1: default
print("Default:")
res1 = model.predict(source=img, save=False)
if res1[0].masks:
    print("Found masks:", len(res1[0].masks))
else:
    print("No masks")

# Test 2: conf=0.1
print("\nConf 0.1:")
res2 = model.predict(source=img, save=False, conf=0.1)
if res2[0].masks:
    print("Found masks:", len(res2[0].masks))
else:
    print("No masks")

# Test 3: imgsz=2048
print("\nImgsz 2048:")
res3 = model.predict(source=img, save=False, conf=0.1, imgsz=2048)
if res3[0].masks:
    print("Found masks:", len(res3[0].masks))
else:
    print("No masks")
