import cv2
import os
import random
import glob

# Test loading masks
mask_dir = "masks"
mask_files = glob.glob(os.path.join(mask_dir, "*.png")) + glob.glob(os.path.join(mask_dir, "*.jpg"))
print(f"Found {len(mask_files)} mask files.")

if mask_files:
    # Pick a random one
    file_path = mask_files[0]
    img = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
    img_h, img_w = img.shape
    print(f"Image shape: {img_w}x{img_h}")
    
    _, thresh = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    print(f"Found {len(contours)} contours.")
    
    for c in contours:
        print("Contour shape:", c.shape)
        # points are in shape (N, 1, 2)
        pts = c.squeeze(1) # shape (N, 2)
        if len(pts) > 3:
            print("First 3 points of contour:", pts[:3])
            break
