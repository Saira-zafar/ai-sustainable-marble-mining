import os
from dotenv import load_dotenv
from google import genai
from google.genai import types

# Load .env
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

client = genai.Client()

prompt = """
Provide 3-4 recommendations for mining waste.
Format your response as a JSON array of objects, where each object has:
- "title": a short title (2-4 words)
- "description": a brief actionable recommendation (1 sentence)
- "type": one of "environmental", "operational", or "compliance"
Respond ONLY with the JSON array.
"""

try:
    # Test with response_mime_type
    response = client.models.generate_content(
        model='gemini-2.5-flash',
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json"
        )
    )
    print("SUCCESS")
    print(response.text)
except Exception as e:
    print("ERROR:", e)
