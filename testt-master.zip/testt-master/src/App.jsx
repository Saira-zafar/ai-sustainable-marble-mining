import React, { useState, useCallback, useEffect } from 'react';
import * as Cesium from 'cesium';
import Globe from './components/Globe';
import MapboxGlobe from './components/MapboxGlobe';
import SearchBar from './components/SearchBar';
import SidebarLeft from './components/SidebarLeft';
import { Target, Lightbulb, Loader2 } from 'lucide-react';
import './App.css';

function App() {
  const [activeMap, setActiveMap] = useState(null);
  const [mapEngine, setMapEngine] = useState('cesium');
  const [isRotating, setIsRotating] = useState(true);
  const [minesData, setMinesData] = useState(null);
  const [mineCount, setMineCount] = useState(0);
  const [wasteStats, setWasteStats] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [liveDetection, setLiveDetection] = useState(32.02);
  const [recommendations, setRecommendations] = useState(null);
  const [isRecommending, setIsRecommending] = useState(false);

  // ── Live detection jitter ────────────────────────────────────────────────
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveDetection(prev => {
        const change = (Math.random() - 0.5) * 0.05;
        return +(prev + change).toFixed(2);
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const ionToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI5NDkyMWI1Yi00M2Y4LTQ0Y2EtODcwZi0wN2RiMGQxYzAzZDUiLCJpZCI6NDE3MjQ4LCJpYXQiOjE3NzYwMjc2NDl9.0lDcv4GyFBbzgOJRh5mGB_0TMr8_5kA8uJoX5HdOV0s';

  // ── Load mines from public/mines.geojson on startup ──────────────────────
  useEffect(() => {
    fetch('/mines.geojson')
      .then(r => r.json())
      .then(data => {
        console.log(`✓ Loaded ${data.features.length} KML mine polygons`);
        setMinesData(data);
        setMineCount(data.features.length);
      })
      .catch(err => console.error('Could not load mines.geojson:', err));
  }, []);

  // ── Draw as soon as map + data are ready ─────────────────────────────────
  useEffect(() => {
    if (!activeMap || !minesData) return;
    renderStaticMines(minesData);
  }, [activeMap, minesData]);

  const handleMapReady = useCallback((mapInstance) => {
    setActiveMap(mapInstance);
  }, []);

  // ── Generate realistic mine waste dump stats ────────────────────────────
  const WASTE_CATEGORIES = [
    { label: 'Mine Waste Dumps', color: '#003399', baseRange: [18, 26] },
  ];

  const generateWasteStats = (totalHa = null) => {
    // Bampokha site total waste footprint ~320–520 ha
    const total = totalHa ?? (320 + Math.random() * 200);
    const raw = WASTE_CATEGORIES.map(c => {
      const [lo, hi] = c.baseRange;
      return lo + Math.random() * (hi - lo);
    });
    const sum = raw.reduce((a, b) => a + b, 0);
    const stats = WASTE_CATEGORIES.map((c, i) => {
      const pct = (raw[i] / sum) * 100;
      return { ...c, pct: +pct.toFixed(1), ha: Math.round((pct / 100) * total) };
    });
    stats.sort((a, b) => b.pct - a.pct);
    setWasteStats({ items: stats, totalHa: Math.round(total), analyzedAt: new Date() });
  };

  const handleSearch = (result) => {
    if (!activeMap) {
      console.warn("activeMap is not set. Map might not be loaded yet.");
      return;
    }
    console.log("Flying to location:", result);
    setIsRotating(false);
    const { lat, lon, rawResult } = result;
    let altitude = 6500;
    let zoom = 14;

    if (rawResult?.boundingbox) {
      const [latMin, latMax, lonMin, lonMax] = rawResult.boundingbox.map(parseFloat);
      const latDiff = Math.abs(latMax - latMin);
      const isCountryType = rawResult.addresstype === 'country' || rawResult.type === 'administrative';
      if (latDiff > 0.5 || isCountryType) {
        altitude = Math.min(2000000, Math.max(15000, latDiff * 100000));
        zoom = latDiff > 10 ? 4 : latDiff > 5 ? 6 : 8;
      }
    }

    if (mapEngine === 'cesium') {
      activeMap.camera.flyTo({
        destination: Cesium.Cartesian3.fromDegrees(lon, lat, altitude),
        orientation: {
          heading: Cesium.Math.toRadians(0.0),
          pitch: Cesium.Math.toRadians(-90.0),
          roll: 0.0
        },
        duration: 3.5,
        easingFunction: Cesium.EasingFunction.QUADRATIC_IN_OUT,
        complete: () => {
          setIsAnalyzing(true);
          triggerVisionDetection();
        }
      });
    } else {
      activeMap.flyTo({ center: [lon, lat], zoom, essential: true, duration: 3500 });
      activeMap.once('moveend', () => {
        setIsAnalyzing(true);
        triggerVisionDetection();
      });
    }
  };

  const triggerVisionDetection = async () => {
    // Simulate a short analysis delay, then generate waste dump stats
    await new Promise(resolve => setTimeout(resolve, 1200));
    generateWasteStats();
    setIsAnalyzing(false);
    
    // Trigger AI Recommendations
    setIsRecommending(true);
    try {
      const response = await fetch('http://localhost:8000/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          coverage_pct: liveDetection,
          detection_count: mineCount || 16,
          waste_ha: wasteStats?.totalHa || 420.5
        })
      });
      if (response.ok) {
        const data = await response.json();
        setRecommendations(data);
      }
    } catch (err) {
      console.error('Failed to fetch recommendations:', err);
    } finally {
      setIsRecommending(false);
    }
  };

  // ── Pulsing dot ───────────────────────────────────────────────────────────
  const addPulsingDot = (map) => {
    if (map.hasImage('pulsing-dot')) return;
    const size = 80;
    map.addImage('pulsing-dot', {
      width: size, height: size, data: new Uint8Array(size * size * 4),
      onAdd() { const c = document.createElement('canvas'); c.width = c.height = size; this.ctx = c.getContext('2d'); },
      render() {
        const t = (performance.now() % 1500) / 1500, r = size / 2, ctx = this.ctx;
        ctx.clearRect(0, 0, size, size);
        ctx.beginPath(); ctx.arc(r, r, r * 0.85 * t + r * 0.15, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255,255,255,${0.5 * (1 - t)})`; ctx.fill();
        ctx.beginPath(); ctx.arc(r, r, r * 0.22, 0, Math.PI * 2);
        ctx.fillStyle = '#fff'; ctx.strokeStyle = 'rgba(255,140,0,0.9)'; ctx.lineWidth = 2;
        ctx.fill(); ctx.stroke();
        this.data = ctx.getImageData(0, 0, size, size).data; map.triggerRepaint(); return true;
      }
    }, { pixelRatio: 2 });
  };

  // ── Render KML-derived mine polygons (white outlines, always visible) ────
  const renderStaticMines = (geojsonData) => {
    if (!geojsonData?.features?.length) return;
    console.log(`Drawing ${geojsonData.features.length} KML mine polygons`);

    if (mapEngine === 'cesium') {
      if (window.staticMinesSource) activeMap.dataSources.remove(window.staticMinesSource);
      Cesium.GeoJsonDataSource.load(geojsonData, { clampToGround: true }).then(source => {
        source.entities.values.forEach(entity => {
          if (entity.polygon) {
            // GEE-style: dark blue outline, slightly darker fill for visibility
            entity.polygon.material = Cesium.Color.fromCssColorString('#003399').withAlpha(0.22);
            entity.polygon.outline = true;
            entity.polygon.outlineColor = Cesium.Color.fromCssColorString('#003399');
            entity.polygon.outlineWidth = 3;
          }
        });
        window.staticMinesSource = source;
        activeMap.dataSources.add(source);
      });

    } else {
      const apply = () => {
        if (activeMap.getSource('static-mines')) {
          activeMap.getSource('static-mines').setData(geojsonData); return;
        }
        activeMap.addSource('static-mines', { type: 'geojson', data: geojsonData });

        // GEE-style: slightly darker blue fill for visibility
        activeMap.addLayer({
          id: 'static-mine-fill', type: 'fill', source: 'static-mines',
          paint: { 'fill-color': '#003399', 'fill-opacity': 0.22 }
        });

        // GEE-style: dark blue outline, thicker
        activeMap.addLayer({
          id: 'static-mine-outline', type: 'line', source: 'static-mines',
          paint: { 'line-color': '#003399', 'line-width': 2.5, 'line-opacity': 1.0 }
        });

        // Mine number label inside each polygon
        activeMap.addLayer({
          id: 'static-mine-labels', type: 'symbol', source: 'static-mines',
          layout: {
            'text-field': ['concat', 'Mine #', ['to-string', ['get', 'mine_id']]],
            'text-font': ['Open Sans Bold', 'Arial Unicode MS Bold'],
            'text-size': 10,
            'text-anchor': 'center',
            'text-allow-overlap': false
          },
          paint: {
            'text-color': '#ffffff',
            'text-halo-color': 'rgba(0,0,0,0.85)',
            'text-halo-width': 1.5
          }
        });
      };
      activeMap.isStyleLoaded() ? apply() : activeMap.once('styledata', apply);
    }
  };


  return (
    <div className="app-container">
      {mapEngine === 'cesium' ? (
        <Globe onReady={handleMapReady} ionToken={ionToken} />
      ) : (
        <MapboxGlobe onReady={handleMapReady} />
      )}
      <SidebarLeft activeEngine={mapEngine} onEngineChange={setMapEngine} />
      <div className="ui-overlay">
        <div className="search-wrapper">
          <SearchBar onSearch={handleSearch} />
          <div className="quick-actions">
            <button
              type="button"
              className="quick-action-btn glass-morphism"
              onClick={() => handleSearch({
                // KML geographic center: lon 72.3000, lat 34.5141
                // bbox covers all 16 polygons: lon 72.2545-72.3454, lat 34.4913-34.5369
                lat: 34.5141,
                lon: 72.3000,
                display_name: 'Bampokha Mining Site',
                rawResult: {
                  boundingbox: ['34.491', '34.537', '72.254', '72.346'],
                  addresstype: 'industrial'
                }
              })}
            >
              <Target size={16} color="#00C8FF" />
              <span>Analyze Bampokha</span>
            </button>
          </div>
        </div>

        {/* ── Legend & Detection Results (Bottom Right) ── */}
        <div className="bottom-right-container">
          <div className="info-card glass-morphism animate-slide-in">
            <div className="card-header">LEGEND</div>
            <div className="legend-row">
              <div className="color-box"></div>
              <span className="legend-label">Waste Area</span>
            </div>
          </div>

          {/* ── AI Recommendations Panel ── */}
          {(isRecommending || recommendations) && (
            <div className="recommendations-container glass-morphism animate-slide-in">
              <div className="card-header" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Lightbulb size={16} color="#00C8FF" />
                AI RECOMMENDATIONS
              </div>
              <div className="recommendations-content">
                {isRecommending ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '15px 0', color: 'rgba(255,255,255,0.6)' }}>
                    <Loader2 className="animate-spin" size={18} />
                    <span>Generating insights with Gemini...</span>
                  </div>
                ) : recommendations ? (
                  <ul className="recommendations-list">
                    {recommendations.map((rec, idx) => (
                      <li key={idx} className={`rec-item type-${rec.type}`}>
                        <div className="rec-title">{rec.title}</div>
                        <div className="rec-desc">{rec.description}</div>
                      </li>
                    ))}
                  </ul>
                ) : null}
              </div>
            </div>
          )}

          <div className="info-card glass-morphism animate-slide-in" style={{ animationDelay: '0.15s' }}>
            <div className="card-header">DETECTION RESULTS</div>
            <div className="detection-main">
              <span className="detection-percentage">{liveDetection}%</span>
              <span className="detection-label">WASTE</span>
            </div>
            <div className="detection-count">16 DETECTIONS FOUND</div>
          </div>
        </div>

        {/* Mine count badge */}
        {mineCount > 0 && (
          <div style={{
            position: 'absolute', bottom: 10, right: 20,
            background: 'rgba(0,0,0,0.6)', color: 'rgba(255,255,255,0.45)',
            padding: '5px 12px', borderRadius: 6,
            fontSize: 11, border: '1px solid rgba(255,255,255,0.1)'
          }}>
            🗺 {mineCount} polygons loaded
          </div>
        )}

      </div>
    </div>
  );
}

export default App;
