import React from 'react';
import { Layers, Database, Sliders } from 'lucide-react';

const SidebarLeft = ({ activeEngine, onEngineChange }) => {
  return (
    <div className="sidebar sidebar-left glass-morphism">
      <div className="sidebar-section">
        <h3><Layers size={14} style={{ marginRight: '8px', verticalAlign: 'middle' }} /> Map Engine</h3>
        <p style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.4)', margin: '8px 0 15px' }}>
          SELECT VISUALIZATION CORE
        </p>
        <div className="btn-group" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <button
            className={`terrabit-btn ${activeEngine === 'cesium' ? 'active' : ''}`}
            onClick={() => onEngineChange('cesium')}
          >
            Cesium 3D
          </button>
          <button
            className={`terrabit-btn ${activeEngine === 'mapbox' ? 'active' : ''}`}
            onClick={() => onEngineChange('mapbox')}
          >
            Mapbox GL
          </button>
        </div>
      </div>

      <div className="sidebar-section">
        <h3><Database size={14} style={{ marginRight: '8px', verticalAlign: 'middle' }} /> Exemplars</h3>
        <div style={{ padding: '24px 15px', textAlign: 'center', background: 'rgba(255,255,255,0.02)', border: '1px dashed rgba(255,255,255,0.1)', borderRadius: '12px', fontSize: '0.75rem', color: 'rgba(255,255,255,0.3)' }}>
          NO FEATURES INDEXED
        </div>
      </div>

      <div className="sidebar-section">
        <h3><Sliders size={14} style={{ marginRight: '8px', verticalAlign: 'middle' }} /> Sensitivity</h3>
        <div style={{ marginTop: '10px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.7rem', color: 'rgba(255,255,255,0.6)' }}>
            <span>DETECTION THRESHOLD</span>
            <span style={{ color: '#00C8FF' }}>50%</span>
          </div>
          <input 
            type="range" 
            min="1" 
            max="100" 
            defaultValue="50" 
            style={{ 
              width: '100%', 
              accentColor: '#00C8FF', 
              marginTop: '12px',
              height: '3px',
              background: 'rgba(255,255,255,0.1)'
            }} 
          />
        </div>
      </div>

      <div className="sidebar-footer-brand">
        <h2>Earth 3D</h2>
      </div>
    </div>
  );
};

export default SidebarLeft;
