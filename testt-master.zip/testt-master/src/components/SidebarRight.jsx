import React from 'react';

const SidebarRight = () => {
  const exploreItems = [
    { title: 'Malé Atoll', type: 'coral atoll' },
    { title: 'Rotterdam', type: 'port' },
    { title: 'Atacama', type: 'lithium mines' },
    { title: 'Palm Island', type: 'coastal eng.' },
  ];

  const discoveries = [
    { title: 'Moosonee', type: 'boreal' },
    { title: 'Comoros', type: 'tropical' },
    { title: 'Dead Sea', type: 'isolated' },
  ];

  return (
    <div className="sidebar sidebar-right">
      <div>
        <h3>Explore</h3>
        <div style={{ marginTop: '10px' }}>
          {exploreItems.map((item, idx) => (
            <div key={idx} className="list-item">
              <div className="title">{item.title}</div>
              <div className="subtitle">{item.type}</div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3>Discoveries</h3>
        <div style={{ marginTop: '10px' }}>
          {discoveries.map((item, idx) => (
            <div key={idx} className="list-item">
              <div className="title">{item.title}</div>
              <div className="subtitle">{item.type} (verified)</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SidebarRight;
