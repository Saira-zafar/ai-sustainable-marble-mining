import React, { useState } from 'react';
import { Search, MapPin, Loader2 } from 'lucide-react';

const SearchBar = ({ onSearch }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setShowDropdown(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5`
      );
      const data = await response.json();
      setResults(data);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (result) => {
    const lat = parseFloat(result.lat);
    const lon = parseFloat(result.lon);
    onSearch({ lat, lon, name: result.display_name, rawResult: result });
    setShowDropdown(false);
    setQuery(result.display_name);
  };

  return (
    <div className="search-container">
      <form onSubmit={handleSearch} className="search-form glass-morphism">
        <button type="submit" className="search-icon-btn" style={{ background: 'transparent', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', color: 'rgba(255,255,255,0.4)', transition: 'var(--transition-smooth)' }}>
          {loading ? <Loader2 className="animate-spin" size={18} /> : <Search size={20} />}
        </button>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="SEARCH LOCATIONS..."
          className="search-input"
          style={{ letterSpacing: '1px', textTransform: 'uppercase', fontSize: '0.8rem' }}
        />
      </form>

      {showDropdown && results.length > 0 && (
        <ul className="results-dropdown glass-morphism" style={{ 
          marginTop: '12px', 
          borderRadius: '16px', 
          padding: '8px', 
          listStyle: 'none', 
          maxHeight: '280px', 
          overflowY: 'auto',
          pointerEvents: 'auto',
          width: '100%',
          boxShadow: '0 20px 40px rgba(0,0,0,0.5)'
        }}>
          {results.map((result) => (
            <li 
              key={result.place_id} 
              onClick={() => handleSelect(result)} 
              className="result-item"
              style={{
                padding: '10px 14px',
                borderRadius: '10px',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                transition: 'var(--transition-smooth)'
              }}
            >
              <MapPin size={16} style={{ color: 'var(--accent-color)', opacity: 0.8 }} />
              <div className="item-text" style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                <span className="item-name" style={{ fontSize: '0.85rem', fontWeight: '600', color: '#fff', letterSpacing: '0.5px' }}>
                  {result.display_name.split(',')[0].toUpperCase()}
                </span>
                <span className="item-sub" style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.3)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '350px', letterSpacing: '0.5px' }}>
                  {result.display_name.split(',').slice(1).join(',').toUpperCase()}
                </span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SearchBar;
