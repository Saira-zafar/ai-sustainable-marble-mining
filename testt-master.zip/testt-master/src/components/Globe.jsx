import React, { useEffect, useRef, useState } from 'react';
import * as Cesium from 'cesium';
import 'cesium/Build/Cesium/Widgets/widgets.css';

const Globe = ({ onReady, ionToken }) => {
    const containerRef = useRef(null);
    const viewerRef = useRef(null);
    const [isMounted, setIsMounted] = useState(false);

    useEffect(() => {
        setIsMounted(true);
    }, []);

    useEffect(() => {
        if (!isMounted || !containerRef.current || viewerRef.current) return;

        let viewer;

        const initialize = async () => {
            try {
                if (ionToken) Cesium.Ion.defaultAccessToken = ionToken;

                // 🌍 Satellite with labels
                const imagery = await Cesium.createWorldImageryAsync({
                    style: Cesium.IonWorldImageryStyle.AERIAL_WITH_LABELS
                });

                viewer = new Cesium.Viewer(containerRef.current, {
                    animation: false,
                    baseLayerPicker: false,
                    fullscreenButton: false,
                    geocoder: false,
                    homeButton: false,
                    infoBox: false,
                    timeline: false,
                    navigationHelpButton: false,
                    sceneModePicker: false,
                    selectionIndicator: false,
                    scene3DOnly: true,
                    baseLayer: new Cesium.ImageryLayer(imagery),
                    contextOptions: {
                        webgl: {
                            preserveDrawingBuffer: true
                        }
                    }
                });

                const scene = viewer.scene;
                const globe = scene.globe;

                // ✅ ENABLE CAMERA CONTROLS (FIX ZOOM ISSUE)
                const controller = scene.screenSpaceCameraController;
                controller.enableZoom = true;
                controller.enableRotate = true;
                controller.enableTilt = true;
                controller.enableLook = true;

                // Optional limits (better UX)
                controller.minimumZoomDistance = 1000;
                controller.maximumZoomDistance = 20000000;

                // 🔧 CLARITY
                globe.maximumScreenSpaceError = 1.0;
                viewer.resolutionScale = 2.0; 
                scene.postProcessStages.fxaa.enabled = true;

                // 🌤️ VISUALS
                scene.skyAtmosphere = new Cesium.SkyAtmosphere();
                globe.showGroundAtmosphere = true;
                globe.enableLighting = false;
                scene.highDynamicRange = true;

                // ⚠️ IMPORTANT (for borders visibility)
                globe.depthTestAgainstTerrain = false;

                // ⛰️ Terrain
                const terrain = await Cesium.createWorldTerrainAsync();
                viewer.terrainProvider = terrain;

                // 🌍 COUNTRY BORDERS
                // Disabled due to known crash "Too many properties to enumerate" on large polygons
                /*
                const dataSource = await Cesium.GeoJsonDataSource.load(
                    "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson"
                );

                viewer.dataSources.add(dataSource);

                const entities = dataSource.entities.values;

                for (let entity of entities) {
                    if (entity.polygon) {
                        entity.polygon.material = Cesium.Color.TRANSPARENT;
                        entity.polygon.outline = true;
                        entity.polygon.outlineColor = Cesium.Color.WHITE.withAlpha(0.8);
                        entity.polygon.outlineWidth = 1.5;
                    }
                }
                */

                viewerRef.current = viewer;
                if (onReady) onReady(viewer);

            } catch (err) {
                console.error("Cesium Initialization Error:", err);
            }
        };

        initialize();

        return () => {
            if (viewer && !viewer.isDestroyed()) viewer.destroy();
            viewerRef.current = null;
        };
    }, [isMounted, ionToken, onReady]);

    return (
        <div
            ref={containerRef}
            className="globe-container"
            style={{ position: 'fixed', inset: 0, background: '#000' }}
        />
    );
};

export default Globe;