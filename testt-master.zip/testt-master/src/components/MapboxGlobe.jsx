import React, { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

/**
 * MapboxGlobe Component
 * Provides a high-fidelity 3D Globe with vector borders and labels.
 * 
 * HOW TO GET TOKEN:
 * 1. Go to mapbox.com and sign up.
 * 2. Get your Public Token (pk.xxx) from the dashboard.
 * 3. Create a .env file in the root directory.
 * 4. Add: VITE_MAPBOX_ACCESS_TOKEN=your_token_here
 */

const MapboxGlobe = ({ onReady, accessToken }) => {
    const mapContainerRef = useRef(null);
    const mapRef = useRef(null);

    useEffect(() => {
        if (mapRef.current || !mapContainerRef.current) return;

        // Use the provided accessToken or a placeholder
        const token = accessToken || import.meta.env.VITE_MAPBOX_ACCESS_TOKEN || '';
        if (!token) {
            console.error("Mapbox token missing! See instructions in MapboxGlobe.jsx");
        }
        mapboxgl.accessToken = token;

        const map = new mapboxgl.Map({
            container: mapContainerRef.current,
            style: 'mapbox://styles/mapbox/satellite-streets-v12', // Satellite + Hybrid Labels
            center: [0, 20],
            zoom: 1.5,
            projection: 'globe', // This makes it a 3D Globe
            preserveDrawingBuffer: true
        });

        map.on('style.load', () => {
            // Set atmospheric fog for the "space" look
            map.setFog({
                'color': 'rgb(186, 210, 235)', // Lower atmosphere
                'high-color': 'rgb(36, 92, 223)', // Upper atmosphere
                'horizon-blend': 0.02, // Atmosphere thickness
                'space-color': 'rgb(11, 11, 25)', // Background color
                'star-intensity': 0.6 // Stars brightness
            });
        });

        mapRef.current = map;

        if (onReady) {
            // We pass a simplified interface to match Cesium's flyTo structure if needed
            // or just the raw map object.
            onReady(map);
        }

        return () => {
            if (mapRef.current) {
                mapRef.current.remove();
                mapRef.current = null;
            }
        };
    }, [onReady, accessToken]);

    return (
        <div
            ref={mapContainerRef}
            className="mapbox-container"
            style={{ position: 'fixed', inset: 0, background: '#000' }}
        />
    );
};

export default MapboxGlobe;
